#ifndef __OTA_COMMON_H__
#define __OTA_COMMON_H__

#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <mqueue.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/udp.h>
#include <arpa/inet.h>
#include <unistd.h>

/** Socket communication config  **/
#define BUFF_SIZE       ( 2048 )
#define SEND_BUFF_SIZE  ( 14 )

#define MASTER_ADDR     "192.168.0.18" // HostPC
#define MASTER_PORT     ( 33333 )

#define TARGET_ADDR     "192.168.0.2"  // U2A
#define TARGET_PORT     ( 33333 )

#define OTA_DOWNLOAD_FILE "ota_dummy_file"

/** OTA information **/
#define OTA_INSTALL_AREA    (0x00400000)        // Re-write First Address 
#define OTA_INSTALL_SIZE    (1024 * 1024 * 4)   // Re-write size

/**  defines for message queue        **/
#define J_OTA_QUEUE_NAME          "/ota_master_queue"     /** msg queue name **/
#define J_OTA_QUEUE_MAXMSG        ( 10 )                  /** msg queue max num **/
#define J_OTA_STATUS_QUEUE_NAME   "/ota_master_result"
#define J_OTA_STATUS_QUEUE_MAXMSG ( 10 )                  /** msg queue max num **/
typedef int64_t J_OTA_STATUS_QUEUE_t;

/**  defines for test command   **/
enum J_OTA_FUNC {
    J_OTA_FUNC_SYNCCOMPOSE, //          ( 0 )   /**  Function ID: ComponentsSyncronization          **/
    J_OTA_FUNC_DOWNLOAD, //             ( 1 )   /**  Function ID: Download                          **/
    J_OTA_FUNC_INSTALL, //              ( 2 )   /**  Function ID: Install                           **/
    J_OTA_FUNC_ACTIVATE, //             ( 3 )   /**  Function ID: Activate                          **/
    J_OTA_FUNC_ROLLBACK, //             ( 4 )   /**  Function ID: Rollback                          **/
    J_OTA_FUNC_SIZE, //                 ( 5 )
};

enum J_OTA_STATUS {
    J_OTA_STATUS_SUCCESS, //          ( 0 )
    J_OTA_STATUS_FAILED, //           ( 1 )
    J_OTA_STATUS_SIZE, //             ( 2 )
};

/**  Message queue data componet  **/
typedef struct _J_OTA_Message_Queue_Data_ {
    int64_t command;    /** test command **/
    /* TODO：必要に応じてパラメータを追加 */
} J_OTA_Message_Queue_Data ;

unsigned char ack_buf[] = { 0x00, 0x00, 'O', 'K', 0xff, 0x00 };
unsigned char cmd_buf[SEND_BUFF_SIZE] = { 0xff, 'C', 'M', 'D', 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF };

#endif // __OTA_COMMON_H_

// #define J_OTA_FUNC_SYNCCOMPOSE          ( 0 )   /**  Function ID: ComponentsSyncronization          **/
// #define J_OTA_FUNC_DOWNLOAD             ( 1 )   /**  Function ID: Download                          **/
// #define J_OTA_FUNC_INSTALL              ( 2 )   /**  Function ID: Install                           **/
// #define J_OTA_FUNC_ACTIVATE             ( 3 )   /**  Function ID: Activate                          **/
// #define J_OTA_FUNC_ROLLBACK             ( 4 )   /**  Function ID: Rollback                          **/
// #define J_OTA_FUNC_SIZE                 ( 5 )
