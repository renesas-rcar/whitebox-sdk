#include "ota-common.h"
#include "../TFTPserver/includes/functions.h"

#define NL()    printf("\n");

// -- Global variable--------------------------------------
unsigned char recv_buffer[BUFF_SIZE];
unsigned char send_buffer[SEND_BUFF_SIZE];
int send_sock, recv_sock;
struct sockaddr_in master_addr, target_addr, tmp_addr;
socklen_t tmp_addr_size;
char g_MASTER_ADDR[] = "255.255.255.255";
int  g_MASTER_PORT   = 33333;
char g_TARGET_ADDR[] = "255.255.255.255";
int  g_TARGET_PORT   = 33333;
// --------------------------------------------------------

void print_buf(unsigned char* buf) 
{
    printf("%x %x ", buf[0], buf[1]);
    for(int i=2; buf[i] != 0x00; ++i) 
    {
        printf("%x ", buf[i]);
    }
}

void print_ASCII(unsigned char* buf, int len)
{
    int i;

    printf("( ");
    for (i = 0; i < len; i++)
    {
        printf("%c", buf[i]);
    }
    printf(" )\n");
}

void display_msg_type(int msgtype)
{
    switch (msgtype)
    {
        case J_OTA_FUNC_SYNCCOMPOSE:
            printf("\nCommand : sync (%d)\n\n", (int)msgtype);
            break;
        case J_OTA_FUNC_DOWNLOAD:
            printf("\nCommand : download (%d)\n\n", (int)msgtype);
            break;
        case J_OTA_FUNC_INSTALL:
            printf("\nCommand : install (%d)\n\n", (int)msgtype);
            break;
        case J_OTA_FUNC_ACTIVATE:
            printf("\nCommand : activate (%d)\n\n", (int)msgtype);
            break;
        case J_OTA_FUNC_ROLLBACK:
            printf("\nCommand : rollback (%d)\n\n", (int)msgtype);
            break;
        default:
            printf("\nNot supported (%d)\n\n", (int)msgtype);
            break;
    }
}

void recv_message(mqd_t mqd, int* msgtype) 
{
    J_OTA_Message_Queue_Data msg = { 0 };
    struct mq_attr attr;
    ssize_t recv_size = -1;

    mq_getattr( mqd ,&attr );
    recv_size = mq_receive( mqd, (char*)&msg, sizeof(msg), NULL);
    if ( recv_size == -1 ) 
    {
        printf("[ERROR]%d: %s\n", errno, strerror(errno));
        exit(EXIT_FAILURE);
    }

    *msgtype = msg.command;
}

void ether_terminate(void)
{
    close(send_sock);
    close(recv_sock);
}

int ether_init(void)
{
    int ret = 0;

    // Set Target
    target_addr.sin_family = AF_INET;
    target_addr.sin_port = htons(g_TARGET_PORT);
    target_addr.sin_addr.s_addr = inet_addr(g_TARGET_ADDR);

    // Set Master
    master_addr.sin_family = AF_INET;
    master_addr.sin_port = htons(g_MASTER_PORT);
    master_addr.sin_addr.s_addr = INADDR_ANY;

    // Set socket
    send_sock = socket(AF_INET, SOCK_DGRAM, 0);
    recv_sock = socket(AF_INET, SOCK_DGRAM, 0);
    if( send_sock < 0 ) 
    {
        perror("Can't create socket");
        goto EXIT_INIT;
    }

    // Set bind
    ret = bind(recv_sock, (struct sockaddr *)&master_addr, sizeof(master_addr));
    if( ret < 0) 
    {
        perror("Failed to bind socket");
        goto EXIT_INIT;
    }
#if 1
    // Set recieve timeout
    struct timeval timeout = {RECV_TIMEOUT_TIME,0}; //sec and usec
    if (setsockopt(recv_sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout)) == -1)
    {
        perror("setsockop error");
        goto EXIT_INIT;
    }
#endif
    return 0;

EXIT_INIT:
    ether_terminate();
    return -1;
}

int ota_com_Sync(void)
{
    int ret;
    struct sockaddr_in tmp_addr;
    socklen_t tmp_addr_size;

    memset(recv_buffer, 0, BUFF_SIZE);
    memset(send_buffer, 0, SEND_BUFF_SIZE);
    memcpy(send_buffer, cmd_buf, sizeof(cmd_buf));
    ether_init();

    // Send command packet
    send_buffer[0] = 0x00;
    printf("Send packet: "); print_buf(send_buffer); NL();
    ret = sendto(send_sock, send_buffer, sizeof(send_buffer), 0, (struct  sockaddr*)&target_addr, sizeof(target_addr));
    if ( ret < 0 ) 
    {
        perror("Send error");
        goto EXIT_OTA_SYNC;
    }

    // Recv ack packet
    printf("Wait packet..\n");
    tmp_addr_size = sizeof(tmp_addr);
    ret = recvfrom(recv_sock, recv_buffer, sizeof(recv_buffer), 0, (struct  sockaddr*)&tmp_addr, &tmp_addr_size);
    if (ret == -1) 
    {
        perror("Recv: Timeout");
        goto EXIT_OTA_SYNC;
    }

    if ( strncmp(recv_buffer, ack_buf, sizeof(ack_buf)) != 0) 
    {
        perror("Recv: Ack packet is invalid");
        goto EXIT_OTA_SYNC;
    }
    else
    {
        printf("Recv packet: "); print_buf(recv_buffer);NL();
    }
    sleep(3);

    // Recv result packet
    printf("Wait packet..\n");
    tmp_addr_size = sizeof(tmp_addr);
    ret = recvfrom(recv_sock, recv_buffer, sizeof(recv_buffer), 0, (struct  sockaddr*)&tmp_addr, &tmp_addr_size);
    if (ret == -1) 
    {
        perror("Recv: Timeout");
        goto EXIT_OTA_SYNC;
    }
    else
    {
        printf("Recv packet: "); print_buf(recv_buffer); print_ASCII(recv_buffer, ret);
    }

    // Send ack packet
    ret = sendto(send_sock, ack_buf, sizeof(ack_buf), 0, (struct  sockaddr*)&target_addr, sizeof(target_addr));
    if ( ret < 0 ) 
    {
        perror("Send error");
        goto EXIT_OTA_SYNC;
    }
    printf("Send packet: "); print_buf(ack_buf);NL();

    ether_terminate();
    printf("Configuration synchronization success. \n\n");

    return 0;

EXIT_OTA_SYNC:
    ether_terminate();
    return -1;
}

int ota_com_Install(void)
{
    int ret;
    struct sockaddr_in tmp_addr;
    socklen_t tmp_addr_size;
    
    memset(recv_buffer, 0, BUFF_SIZE);
    memset(send_buffer, 0, SEND_BUFF_SIZE);
    memcpy(send_buffer, cmd_buf, sizeof(cmd_buf));
    ether_init();

    // Send command packet
    send_buffer[0] = 0x02;
    send_buffer[5] = (unsigned char)(OTA_INSTALL_AREA);
    send_buffer[6] = (unsigned char)(OTA_INSTALL_AREA >> 8);
    send_buffer[7] = (unsigned char)(OTA_INSTALL_AREA >> 16);
    send_buffer[8] = (unsigned char)(OTA_INSTALL_AREA >> 24);
    send_buffer[9] = (unsigned char)(OTA_INSTALL_AREA);
    send_buffer[10] = (unsigned char)(OTA_INSTALL_AREA >> 8);
    send_buffer[11] = (unsigned char)(OTA_INSTALL_AREA >> 16);
    send_buffer[12] = (unsigned char)(OTA_INSTALL_AREA >> 24);
    printf("Send packet: "); print_buf(send_buffer);NL();
    ret = sendto(send_sock, send_buffer, sizeof(send_buffer), 0, (struct  sockaddr*)&target_addr, sizeof(target_addr));
    if ( ret < 0 ) 
    {
        perror("Send error");
        goto EXIT_OTA_INSTALL;
    }

    // Recv ack packet
    printf("Wait packet..\n");
    tmp_addr_size = sizeof(tmp_addr);
    ret = recvfrom(recv_sock, recv_buffer, sizeof(recv_buffer), 0, (struct  sockaddr*)&tmp_addr, &tmp_addr_size);
    if (ret == -1) 
    {
        perror("Recv: Timeout");
        goto EXIT_OTA_INSTALL;
    }

    if ( strncmp(recv_buffer, ack_buf, sizeof(ack_buf)) != 0) 
    {
        perror("Recv: Ack packet is invalid");
        goto EXIT_OTA_INSTALL;
    }
    else
    {
        printf("Recv packet: "); print_buf(recv_buffer);NL();
    }
#if 0
    // Recv result packet
    printf("Wait packet..\n");
    tmp_addr_size = sizeof(tmp_addr);
    ret = recvfrom(recv_sock, recv_buffer, sizeof(recv_buffer), 0, (struct  sockaddr*)&tmp_addr, &tmp_addr_size);
    if (ret == -1) 
    {
        perror("Recv: Timeout");
        goto EXIT_OTA_INSTALL;
    }
    else
    {
        printf("Recv packet: "); print_buf(recv_buffer); print_ASCII(recv_buffer, ret);
    }
#endif
    // Send ack packet
    ret = sendto(send_sock, ack_buf, sizeof(ack_buf), 0, (struct  sockaddr*)&target_addr, sizeof(target_addr));
    if ( ret < 0 ) 
    {
        perror("Send error");
        goto EXIT_OTA_INSTALL;
    }
    else
    {
        printf("Send packet: "); print_buf(ack_buf);NL();
    }

    // TFTP server start
    printf("\n");
    printf("TFTP server start. \n");
    tftp_server();
    printf("TFTP server end. \n");
    printf("\n");
    
    // Recv result packet
    memset(recv_buffer, 0, BUFF_SIZE);
    printf("Wait packet..\n");
    ret = recvfrom(recv_sock, recv_buffer, sizeof(recv_buffer), 0, (struct  sockaddr*)&tmp_addr, &tmp_addr_size);
    if (ret == -1) 
    {
        perror("Recv: Timeout");
        goto EXIT_OTA_INSTALL;
    }
    else
    {
        printf("Recv packet: "); print_buf(recv_buffer); print_ASCII(recv_buffer, ret);
    }

    ether_terminate();

    return 0;

EXIT_OTA_INSTALL:
    ether_terminate();
    return -1;
}

int ota_com_Activate(void)
{
    int ret;
    struct sockaddr_in tmp_addr;
    socklen_t tmp_addr_size;
    
    memset(recv_buffer, 0, BUFF_SIZE);
    memset(send_buffer, 0, SEND_BUFF_SIZE);
    memcpy(send_buffer, cmd_buf, sizeof(cmd_buf));
    ether_init();

    // Send command packet
    send_buffer[0] = 0x03;
    printf("Send packet: "); print_buf(send_buffer);NL();
    ret = sendto(send_sock, send_buffer, sizeof(send_buffer), 0, (struct  sockaddr*)&target_addr, sizeof(target_addr));
    if ( ret < 0 ) 
    {
        perror("Send error");
        goto EXIT_OTA_ACTIVATE;
    }

    // Recv ack packet
    printf("Wait packet..\n");
    tmp_addr_size = sizeof(tmp_addr);
    ret = recvfrom(recv_sock, recv_buffer, sizeof(recv_buffer), 0, (struct  sockaddr*)&tmp_addr, &tmp_addr_size);
    if (ret == -1) 
    {
        perror("Recv: Timeout");
        goto EXIT_OTA_ACTIVATE;
    }

    if ( strncmp(recv_buffer, ack_buf, sizeof(ack_buf)) != 0) 
    {
        perror("Recv: Ack packet is invalid");
        goto EXIT_OTA_ACTIVATE;
    }
    else
    {
        printf("Recv packet: "); print_buf(recv_buffer);NL();
    }

    // Recv result packet
    printf("Wait packet..\n");
    tmp_addr_size = sizeof(tmp_addr);
    ret = recvfrom(recv_sock, recv_buffer, sizeof(recv_buffer), 0, (struct  sockaddr*)&tmp_addr, &tmp_addr_size);
    if (ret == -1) 
    {
        perror("Recv: Timeout");
        goto EXIT_OTA_ACTIVATE;
    }
    else
    {
        printf("Recv packet: "); print_buf(recv_buffer); print_ASCII(recv_buffer, ret);
    }
    
    ether_terminate();

    return 0;

EXIT_OTA_ACTIVATE:
    ether_terminate();
    return -1;
}

int ota_com_Rollback(void)
{
    int ret;
    struct sockaddr_in tmp_addr;
    socklen_t tmp_addr_size;
    
    memset(recv_buffer, 0, BUFF_SIZE);
    memset(send_buffer, 0, SEND_BUFF_SIZE);
    memcpy(send_buffer, cmd_buf, sizeof(cmd_buf));
    ether_init();

    // Send command packet
    send_buffer[0] = 0x04;
    printf("Send packet: "); print_buf(send_buffer);NL();
    ret = sendto(send_sock, send_buffer, sizeof(send_buffer), 0, (struct  sockaddr*)&target_addr, sizeof(target_addr));
    if ( ret < 0 ) 
    {
        perror("Send error");
        goto EXIT_OTA_ROLLBACK;
    }

    // Recv ack packet
    printf("Wait packet..\n");
    tmp_addr_size = sizeof(tmp_addr);
    ret = recvfrom(recv_sock, recv_buffer, sizeof(recv_buffer), 0, (struct  sockaddr*)&tmp_addr, &tmp_addr_size);
    if (ret == -1) 
    {
        perror("Recv: Timeout");
        goto EXIT_OTA_ROLLBACK;
    }

    if ( strncmp(recv_buffer, ack_buf, sizeof(ack_buf)) != 0) 
    {
        perror("Recv: Ack packet is invalid");
        goto EXIT_OTA_ROLLBACK;
    }
    else
    {
        printf("Recv packet: "); print_buf(recv_buffer);NL();
    }

    // Recv result packet
    printf("Wait packet..\n");
    tmp_addr_size = sizeof(tmp_addr);
    ret = recvfrom(recv_sock, recv_buffer, sizeof(recv_buffer), 0, (struct  sockaddr*)&tmp_addr, &tmp_addr_size);
    if (ret == -1) 
    {
        perror("Recv: Timeout");
        goto EXIT_OTA_ROLLBACK;
    }
    else
    {
        printf("Recv packet: "); print_buf(recv_buffer); print_ASCII(recv_buffer, ret);
    }
    
    ether_terminate();

    return 0;

EXIT_OTA_ROLLBACK:
    ether_terminate();
    return -1;
}

void set_status_queue(mqd_t mqd, J_OTA_STATUS_QUEUE_t status)
{
    int pri = 0;
    int ret = -1;

    if ( mqd == -1 )
    {
        printf("[ERROR]%d: %s\n", errno, strerror(errno));
        return;
    }

    ret = mq_send( mqd, (const unsigned char *)&status, sizeof( status ), pri );
    if ( ret < 0 ) {
        printf( "mq_send failed, mqd:[%d], errno:[%d]\n", mqd, errno);
        mq_close( mqd );
        return;
    }
    printf("Set status queue: %ld\n", status);
}

void parse_arg(int argc, char* argv[]) {
    int i;
    /* copy default value */
    // sscanf(MASTER_PORT, "%d", &g_MASTER_PORT);
    g_MASTER_PORT = MASTER_PORT;
    sprintf(g_MASTER_ADDR, "%s", MASTER_ADDR);
    // sscanf(TARGET_PORT, "%d", &g_TARGET_PORT);
    g_TARGET_PORT = TARGET_PORT;
    sprintf(g_TARGET_ADDR, "%s", TARGET_ADDR);

    // printf("argc is %d\n", argc);
    for(i=0; i< argc;++i) {
        // printf("argv[%d] is %s\n", i, argv[i]);

        if ( strncmp("-mp", argv[i], 3) == 0 ){
            i++;
            sscanf(argv[i], "%d", &g_MASTER_PORT);
        }
        else if ( strncmp("-mi", argv[i], 3) == 0 ) {
            i++;
            sprintf(g_MASTER_ADDR, "%s", argv[i]);
        }
        else if ( strncmp("-tp", argv[i], 3) == 0 ){
            i++;
            sscanf(argv[i], "%d", &g_TARGET_PORT);
        }
        else if ( strncmp("-ti", argv[i], 3) == 0 ) {
            i++;
            sprintf(g_TARGET_ADDR, "%s", argv[i]);
        }
    }

    printf("OTA-master addr is %s\n", g_MASTER_ADDR);
    printf("OTA-master port is %d\n", g_MASTER_PORT);
    printf("OTA-target addr is %s\n", g_TARGET_ADDR);
    printf("OTA-target port is %d\n", g_TARGET_PORT);

    return;
}

int main(int argc, char *argv[])
{
    int ret = -1;
    mqd_t mqd = -1;
    mqd_t mqd_status = -1;
    int msgtype = -1;
    struct  mq_attr attr = { 0 };
    struct  mq_attr attr_status = { 0 };

    /* parsing argument */
    parse_arg(argc, argv);

    /* setup messageque */
    mq_unlink(J_OTA_QUEUE_NAME);
    attr.mq_maxmsg = J_OTA_QUEUE_MAXMSG;
    attr.mq_msgsize = sizeof(J_OTA_Message_Queue_Data);
    mqd = mq_open(J_OTA_QUEUE_NAME, (O_RDONLY|O_CREAT), S_IRUSR | S_IWUSR | S_IWGRP, &attr );
    if ( mqd == -1 )
    {
        printf("[ERROR]%d: %s: queue\n", errno, strerror(errno));
        return -1;
    }

    mq_unlink(J_OTA_STATUS_QUEUE_NAME);
    attr_status.mq_maxmsg = J_OTA_STATUS_QUEUE_MAXMSG;
    attr_status.mq_msgsize = sizeof(J_OTA_STATUS_QUEUE_t);
    mqd_status = mq_open(J_OTA_STATUS_QUEUE_NAME, (O_RDWR|O_CREAT), S_IRUSR | S_IWUSR | S_IWGRP, &attr_status );
    if ( mqd_status == -1 )
    {
        printf("[ERROR]%d: %s: queue_status\n", errno, strerror(errno));
        return -1;
    }


    while(1) 
    {
        printf("Waiting for a command from the upper level... \n");
#if 1
        recv_message(mqd, &msgtype); // waiting for  msg from ota-plugin/ota-test
#else
        msgtype = getchar();
        ota_com_Install();
        //ota_com_Activate();
        //ota_com_Sync();
        return 0;
#endif
        display_msg_type(msgtype);

        switch (msgtype)
        {
            case J_OTA_FUNC_SYNCCOMPOSE:
                ret = ota_com_Sync();
                break;

            case J_OTA_FUNC_DOWNLOAD:
                printf("Not supported. \n");
                ret = J_OTA_STATUS_SUCCESS;
                break;

            case J_OTA_FUNC_INSTALL:
                ret = ota_com_Install();
                break;

            case J_OTA_FUNC_ACTIVATE:
                ret = ota_com_Activate();
                break;

            case J_OTA_FUNC_ROLLBACK:
                ret = ota_com_Rollback();
                break;

            default:
                printf("Not supported. \n");
                ret = J_OTA_STATUS_FAILED;
                break;
        }
        printf("ret = %d\n", ret);
        if( ret == -1 )
            ret = J_OTA_STATUS_FAILED;

        set_status_queue(mqd_status, ret);
    }

    return 0;
}

