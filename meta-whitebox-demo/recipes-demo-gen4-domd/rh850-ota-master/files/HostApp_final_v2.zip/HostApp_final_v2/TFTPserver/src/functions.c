#include "../includes/functions.h"
#include "../includes/header.h"

//#define FILE_PATH   ("var/aos/downloads/")
//#define FILE_PATH   ("./")
#define FILE_PATH   ("/var/aos/downloads/rh850/")

// Debug 
unsigned int check_sum, sum_cnt;

static unsigned char buf[512 + 4], retrybuf[512 + 4];
static int listenfd; //the socket that listens on port 69 for new clients
static int sockfd;
static struct sockaddr_in     servaddr;
static struct sockaddr_in     clientaddr;

void error_and_die(const char errormsg[]){
    perror(errormsg);
    close(listenfd);
    //free(buf);
    exit(EXIT_FAILURE);
}

void die(const char msg[]){
    printf("%s\n", msg);
    close(listenfd);
    //free(buf);
    exit(EXIT_FAILURE);
}

void ctrlc(){
    fprintf(stdout,"Bye\n");
    close(listenfd);
    //free(buf);
    exit(EXIT_SUCCESS);
}


int toclient(){
    int                 blksize = 512; //512 by default
    long int                  file, filesize, recvvalue;
    char                ackbuf[4];
    unsigned long int        blockno = 1;
    ssize_t             recvsize;
    int                 recvcount = 0;
    char                 filename[512], ota_filename[512];
    int transfer_max_size, transfer_size;
    int ret;
    FILE *fp;
    
    srand((unsigned) time(NULL));

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1){
        error_and_die("fork socket error");
    }

#if 1
    struct timeval timeout = {RECV_TIMEOUT_TIME,0}; //sec and usec
    //set recv timeout
    if (setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout)) == -1){
        error_and_die("setsockop error");
    }
#endif

    if (connect(sockfd, (SA*)&clientaddr, sizeof(clientaddr)) == -1){
        error_and_die("connect error");
    }
#if 0
    //forbid access to other directories
    strncpy(filename, buf + 2, blksize);
    if (buf[2] == '.' || buf[2] == '/'){
        sendERR(EROP_ILLTFTPOP," : you cannot change directory.");
    }
#else
    strncpy(ota_filename, buf + 2, blksize);
    sprintf(filename, FILE_PATH);
    strcat(filename, ota_filename);
    printf("%s\n", filename);
#endif
    // --------------------------- RRQ ---------------------------------
    if (buf[0] == 0 && buf[1] == OP_RRQ){
        checkMode();
        
        printf("[OP_RRQ mode]\n");
        printf("\n");
#if 0
        if ((file = open(filename,O_RDONLY)) == -1){
            sendERR(EROP_FILNFOUND, NULL);
        }
#else
        if ((fp = fopen(filename,"r")) == NULL){
            sendERR(EROP_FILNFOUND, NULL);
        }
#endif

        transfer_max_size = 4 * 1024 * 1024;
        transfer_size = 0;
        check_sum = 0;
        while (1)
        {
#if 0
            if ((filesize = read(file, buf + 4, blksize)) == -1)
            {
                error_and_die("read error");
            }
#else
            filesize = fread(buf + 4, 1, blksize, fp);
            if (ferror(fp) != 0)
            {
                fclose(fp);
                error_and_die("read error");
            }
            
            if (filesize < blksize)
            {
                goto FINRRQ;
            }
#endif
            memset(retrybuf, 0, 512 + 4);
            recvcount = 0;
            do 
            {
                buf[1] = OP_DAT;
                buf[2] = (unsigned char) (blockno >> 8) & 0xff;
                buf[3] = (unsigned char) blockno & 0xff;
                memcpy(retrybuf, buf, 512 + 4);

                for (sum_cnt = 0; sum_cnt < blksize; sum_cnt++)
                {
                    check_sum += buf[sum_cnt + 4];
                }
                
                if (send(sockfd, buf, filesize+4, 0) == -1){
                    error_and_die("sendto error");
                }
                
                // 64K���ɐi���\��
                transfer_size += blksize;
                if ((transfer_size % (64*1024)) == 0)
                {
                    printf("Transferred size (%d/%d) [", transfer_size, transfer_max_size);
                    //printf("blkno=%d : fsize = %ld : bsize = %d\n", blockno, filesize, blksize);
                    printf("Check sum : %d]\n", check_sum);
                    //printf("buf[2-3] : %x %x\n", buf[2], buf[3]);
                }
#if 0
                if (filesize < blksize)
                {
                    goto FINRRQ;
                }
#endif
                while (1)
                {
                    ret = recv(sockfd, buf, blksize + 4, 0);
                    if (ret < 0)
                    {
                         if (errno != EAGAIN && errno != EWOULDBLOCK)
                        {
                            error_and_die("recv error");
                        }
                        recvcount++;
                    }
                    else if (ret > 0)
                    {
                        break;
                    }
                    
                    // Retry
                    if (send(sockfd, retrybuf, filesize+4, 0) == -1){
                        error_and_die("sendto error");
                    }
                }
#if 0
                if (recv(sockfd, buf, blksize + 4, 0) == -1)
                {
                     if (errno != EAGAIN && errno != EWOULDBLOCK)
                    {
                        error_and_die("recv error");
                    }
                    recvcount++;
                }
                else 
                {
                    recvcount++;
                }
#endif
                
#if 0
                if(recvcount >= RECV_TIMEOUT_COUNT)
                {
                    die("RECV_TIMEOUT error");
                }
#endif
            } while ((unsigned int)(buf[2] << 8) + (unsigned char) buf[3] != blockno);

            blockno ++;
        }
        FINRRQ:
        printf("\n");
        printf("[Read request success : %s]\n",filename);
        
    }

    // --------------------------- WRQ -------------------------------
    if (buf[0] == 0 && buf[1] == OP_WRQ){
        checkMode();
        printf("OP_WRQ mode\n");

        if ((file = open(filename, O_CREAT|O_WRONLY|O_EXCL, 0666)) == -1){
            sendERR(EROP_FILALREXI, NULL);
        }

        blockno = 0;
        //answer to WRQ is blockno 0
        buf[2] = 0;
        buf[3] = 0;
        recvvalue = blksize + 4;

        while (1){
            recvcount = 0;
            do {
                buf[1] = OP_ACK;
                if (send(sockfd, buf, 4, 0) == -1){
                    error_and_die("send error");
                }

                if (recvvalue < blksize + 4) goto FINWRQ;

                if ((recvvalue = recv(sockfd, buf, blksize + 4, 0)) == -1){
                    if (errno != EAGAIN && errno != EWOULDBLOCK) error_and_die("recv error");
                    recvcount++;
                    if (recvcount >= RECV_TIMEOUT_COUNT) error_and_die ("RECV_TIMEOUT error");
                }

            } while (recvvalue == -1);

            if (write(file, buf + 4, recvvalue - 4) == -1){
                error_and_die("write error");
            }
        }
        FINWRQ:
        printf("Write request sucess : %s\n", filename);
    }

    close(sockfd);
#if 0
    close(file);
#else
    fclose(fp);
#endif
    //exit(EXIT_SUCCESS);

}

void sendERR(int error, char message[]){
    buf[0] = 0;
    buf[1] = OP_ERR;

    buf[2] = 0;
    buf[3] = error;

    switch (error){
        case EROP_FILNFOUND:
            strncpy(buf+4,"File not found.",16);
            break;
        case EROP_ILLTFTPOP:
            strncpy(buf+4,"Illegal TFTP operation.",24);
            break;
        case EROP_FILALREXI:
            strncpy(buf+4,"File already exists.",21);
            break;
        default:
            strncpy(buf+4,"Undefined error.",17);
            break;
    }
    //add the additionnal message
    if (message != NULL) strncpy(buf + 4 + strlen(buf+4) - 1, message, strlen(message)+1);

    if(sendto(sockfd, buf, 4 + strlen(buf+4)+1, 0, (SA*)&clientaddr, sizeof(clientaddr)) == -1){
        error_and_die("sendERR error");
    }
    //exit(EXIT_SUCCESS);
}

Mode checkMode(){
    char* ptr = buf + 2 + strlen(buf + 2) + 1;
    if (!strncasecmp(ptr, "netascii", 8)) sendERR(EROP_ILLTFTPOP, " : netascii not supported.");
    if(!strncasecmp(ptr,"octet",5)) return octet;
    if(!strncasecmp(ptr,"mail",4)) sendERR(EROP_ILLTFTPOP, " : mail mode is obsolete.");

}

void tftp_server()
{
    socklen_t clientsize;
    //buf = calloc(512 + 4, sizeof(char));

    memset(buf, 0, 512 + 4);
    if(signal(SIGINT,ctrlc) == SIG_ERR){
        ctrlc();
    }
    
    if ((listenfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1){
        error_and_die("socket error");
    }


    bzero(&servaddr, sizeof(servaddr));
    servaddr.sin_family      = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port         = htons(BASE_PORT);

    if((bind(listenfd, (SA *)&servaddr, sizeof(servaddr))) == -1){
        printf("bind error on port %d\n", BASE_PORT);
        error_and_die(NULL);
    }

    printf("[waiting for a connection on port %d]\n",BASE_PORT);
    fflush(stdout);

    clientsize = sizeof(clientaddr);
    //buf = reallocarray(buf, 512 + 4, sizeof(char));
    if (recvfrom(listenfd, buf, 512 + 4, 0, (SA *)&clientaddr, &clientsize) == -1){
        error_and_die("69 recvfrom error");
    }
#if 0
    if(fork() == 0){ //fork to take care of client
        close(listenfd);
        //where the magic happens
        toclient();
        exit(EXIT_FAILURE);
    }
    close(listenfd);
#else
    close(listenfd);
    toclient();
#endif
        return;
}

