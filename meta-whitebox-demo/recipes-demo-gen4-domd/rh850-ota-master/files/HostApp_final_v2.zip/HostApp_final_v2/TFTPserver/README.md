# TFTP
A client/server TFTP in C for Linux

# Original code

- https://github.com/nicobld/TFTP/tree/7f846eb49baae4473a328c76caa03406c3e73c2a

# Author

Original developed by : Copyright (c) 2022 nicobld

Modified by Yuya Hamamachi

