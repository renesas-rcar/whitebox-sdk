#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "header.h"

void error_and_die(const char[]);

void tftp_server();
int toclient();
void sendERR(int error, char[]);
Mode checkMode();
void tftp_client_get(char* serverip, char *port, char* filepath);

#endif
