#include "ota-common.h"
#include "../TFTPserver/includes/header.h"
#include "../TFTPclient/includes/functions.h"
#include <unistd.h>

// -- Global variable--------------------------------------
static int send_sock;
static int recv_sock;
static struct sockaddr_in master_addr;
static socklen_t master_addr_size;
static struct sockaddr_in target_addr;
static unsigned char buf[BUFF_SIZE];

char g_MASTER_ADDR[] = "255.255.255.255";
int  g_MASTER_PORT   = 33333;
char g_TARGET_ADDR[] = "255.255.255.255";
int  g_TARGET_PORT   = 33333;
// --------------------------------------------------------


void print_buf(unsigned char* buf) {
    printf("%x %x ", buf[0], buf[1]);
    for(int i=2; buf[i] != 0x00; ++i) {
        printf("%x ", buf[i]);
    }
    printf("\n");
}

int send_ack() {
    printf("Send packet: "); print_buf(ack_buf);
    sendto(send_sock, ack_buf, sizeof(ack_buf), 0, (struct sockaddr*)&master_addr, sizeof(master_addr));
    return 0;
}

int send_version() {
    buf[0] = 0xfe;
    sprintf(buf+1, "%s%d%d%d", "ver", 1, 2, 3); // ver is 1.2.3
    printf("Send packet: "); print_buf(buf);
    sendto(send_sock, buf, sizeof(buf), 0, (struct sockaddr*)&master_addr, sizeof(master_addr));

    int ret = recvfrom(recv_sock, buf, sizeof(buf), 0, (struct sockaddr*)&master_addr, &master_addr_size);
    printf("Recv packet: "); print_buf(buf);
    if ( strncmp(buf, ack_buf, sizeof(ack_buf)) != 0)
        return -1;
    return 0;
}

int ota_sync(){
    int ret = send_version();
    if ( ret != 0 )
        return -1;
    // U2A上で処理する内容はないので何もしない。
    return 0;
}

int ota_download(){ // dummy func
    int ret = send_version(); // 暫定でversionを返すことにする。
    if ( ret != 0 )
        return -1;

    // U2A上で行う処理はないので、何もしない。
    // TODO: どちらのFlashを使っているかとか返す？
    return 0;
}

int ota_install(){ // dummy func
    int ret = ota_sync(); // 暫定でversionを返すことにする。
    if ( ret  )
        return -1;

    // TFTP経由でファイルを取得し、Flashに書き込む
    printf("install mode\n");
    char port[6];
    sprintf(port, "%d", BASE_PORT);
    printf("serverip is %s, port is %s\n", g_MASTER_ADDR, port);
    sleep(3);
    tftp_client_get(g_MASTER_ADDR, port, OTA_DOWNLOAD_FILE);
    printf("End tftp_client_get()\n");
    // サンプルはファイルの受信までの実装。
    // TODO: フラッシュに書き込む処理。
    // 引数イメージ: データ、サイズ、書き込む面？
    // do_writing_flash(ota_data_buff, ota_data_buff_size, flash_part);
    return 0;
}

int ota_activate(){ // dummy_func
    int ret = send_ack(); // 暫定でversionを返すことにする。
    if ( ret != 0  )
        return -1;

    // U2AのFlashを切り替えてリブートする処理を書く。
    // do_activate();
    return 0;
}

int ota_rollback(){ //dummy_func
    int ret = send_ack(); // 暫定でversionを返すことにする。
    if ( ret != 0 )
        return -1;

    // U2AのFlashを切り替えてリブートする処理を書く。
    // 暫定でota_activateと同じ処理とする。
    // do_activate();
    return 0;
}

void ota_wait_for_command() {
    int ota_cmd = -1;
    int ret;

    target_addr.sin_family = AF_INET;
    target_addr.sin_port = htons(g_TARGET_PORT);
    target_addr.sin_addr.s_addr = INADDR_ANY;
    master_addr.sin_family = AF_INET;
    master_addr.sin_port = htons(g_MASTER_PORT);
    master_addr.sin_addr.s_addr = inet_addr(g_MASTER_ADDR);

    send_sock = socket(AF_INET, SOCK_DGRAM, 0);
    recv_sock = socket(AF_INET, SOCK_DGRAM, 0);
    if( send_sock < 0 ) {
        perror("Can't create socket");
        goto END;
    }
    ret = bind(recv_sock, (struct sockaddr *)&target_addr, sizeof(target_addr));
    if ( ret < 0 ) {
        perror("Failed to bind socket");
        goto END;
    }

    printf("Wait packet...\n");
    ret = recvfrom(recv_sock, buf, sizeof(buf), 0, (struct sockaddr*)&master_addr, &master_addr_size);
    printf("Recv packet: "); print_buf(buf);
    if ( ret < 0 ) {
        perror("Recv failed");
        goto END;
    }
    master_addr.sin_port = htons(MASTER_PORT); // Set client PORT
    if ( strncmp(buf+1, cmd_buf+1, sizeof(cmd_buf)-1) != 0) {
        perror("cmd packet is invalid");
        goto END;
    }
    ota_cmd = buf[0];

    //send ack packet
    sendto(send_sock, ack_buf, sizeof(ack_buf), 0, (struct sockaddr*)&master_addr, sizeof(master_addr));
    printf("Send packet: "); print_buf(ack_buf);

    switch (ota_cmd) {
    case J_OTA_FUNC_SYNCCOMPOSE:
        ret = ota_sync();
        break;
    case J_OTA_FUNC_DOWNLOAD:
        ret = ota_download();
        break;
    case J_OTA_FUNC_INSTALL:
        ret = ota_install();
        break;
    case J_OTA_FUNC_ACTIVATE:
        ret = ota_activate();
        break;
    case J_OTA_FUNC_ROLLBACK:
        ret = ota_rollback();
        break;
    }
    if ( ret != 0 )
        goto END;

END:
    close(send_sock);
    close(recv_sock);
}

void parse_arg(int argc, char* argv[]) {
    int i;
    /* copy default value */
    // sscanf(MASTER_PORT, "%d", &g_MASTER_PORT);
    g_MASTER_PORT = MASTER_PORT;
    sprintf(g_MASTER_ADDR, "%s", MASTER_ADDR);
    // sscanf(TARGET_PORT, "%d", &g_TARGET_PORT);
    g_TARGET_PORT = TARGET_PORT;
    sprintf(g_TARGET_ADDR, "%s", TARGET_ADDR);

    // printf("argc is %d\n", argc);
    for(i=0; i< argc;++i) {
        // printf("argv[%d] is %s\n", i, argv[i]);

        if ( strncmp("-mp", argv[i], 3) == 0 ){
            i++;
            sscanf(argv[i], "%d", &g_MASTER_PORT);
        }
        else if ( strncmp("-mi", argv[i], 3) == 0 ) {
            i++;
            sprintf(g_MASTER_ADDR, "%s", argv[i]);
        }
        else if ( strncmp("-tp", argv[i], 3) == 0 ){
            i++;
            sscanf(argv[i], "%d", &g_TARGET_PORT);
        }
        else if ( strncmp("-ti", argv[i], 3) == 0 ) {
            i++;
            sprintf(g_TARGET_ADDR, "%s", argv[i]);
        }
    }

    printf("OTA-master addr is %s\n", g_MASTER_ADDR);
    printf("OTA-master port is %d\n", g_MASTER_PORT);
    printf("OTA-target addr is %s\n", g_TARGET_ADDR);
    printf("OTA-target port is %d\n", g_TARGET_PORT);

    return;
}
int main(int argc, char *argv[]) {
    /* parsing argument */
    parse_arg(argc, argv);

    while(1) {
        ota_wait_for_command();
    }

    return 0;
}

