#include "ota-common.h"

int send_message(int command) {
    J_OTA_Message_Queue_Data msg = { 0 };
    mqd_t mqd = -1;
    int ret = 0;
    int pri = 0;

    /* メッセージキューオープン(書き込み) */
    mqd = mq_open( J_OTA_QUEUE_NAME, O_WRONLY );
    if ( mqd == -1 ) {
        printf( "mq_open failed mqd:[%d], errno:[%d]\n", mqd, errno );
        return -1;
    }

    /* メッセージ送信 */
    msg.command = command;
    ret = mq_send( mqd, (const char *)&msg, sizeof( msg ), pri );
    if ( ret < 0 ) {
        printf( "mq_send failed, mqd:[%d], errno:[%d]\n", mqd, errno);
        mq_close( mqd );
        return -1;
    }
    /* メッセージキュークローズ */
    mq_close( mqd );

    return 0;
}

int check_status_queue() {
    unsigned char status = -1;
    mqd_t mqd;
    struct mq_attr attr;
    ssize_t recv_size = -1;

    do {
        mqd = mq_open(J_OTA_STATUS_QUEUE_NAME, (O_RDONLY), S_IRWXU, &attr );
    } while (mqd == -1);
    mq_getattr( mqd ,&attr );
    printf("mq_open OK\n");

    do {
        recv_size = mq_receive( mqd, (unsigned char*)&status, sizeof(J_OTA_STATUS_QUEUE_t), NULL);
    } while ( recv_size == -1);
    printf("mq_recv OK\n");

    mq_close( mqd );

    return status;
}

const char *msgtype[J_OTA_FUNC_SIZE] = {"sync", "download", "install", "activate", "rollback"};
void usage(void) {
    printf("ota-test <int:MessageType>\n");
    printf("MessageType:\n");
    for( int i=0; i<J_OTA_FUNC_SIZE;++i) {
        printf("\t%d: %s\n", i, msgtype[i]);
    }
    printf("All command test(For debug only):\n");
    printf("    -1: test all command(0 to %d)\n", J_OTA_FUNC_SIZE-1);
    exit(-1);
}

int main(int argc, char *argv[]) {
    int ret = -1;
    int command = -1;
    int status = -1;
    int i = -1;

    if( argc != 2 )
        usage();

    sscanf(argv[1], "%d", &command);
    printf("command = %d\n", command);
    if( command == -1 ) { // all test
        printf("All test mode\n");
        for (i=0; i<J_OTA_FUNC_SIZE; ++i) {
            printf("---- command == %d ----\n", i);
            ret = send_message(i);
            if ( ret == -1 ) {
                printf("Error\n"); exit(-1);
            }

            status = check_status_queue();
            if ( status == J_OTA_STATUS_SUCCESS )
                printf("Success\n");
            else if ( status == J_OTA_STATUS_FAILED )
                printf("Failed\n");
            else
                printf("Unknown status: %d\n", status);

            sleep(1); // wait
        }
        return 0;
    }
    else if( command != -1 && command >= J_OTA_FUNC_SIZE ) {
        perror("invalid argument");
        usage();
    }

    ret = send_message(command);
    if ( ret == -1 ) {
        printf("Error\n");
        exit(-1);
    }

    status = check_status_queue();
    if ( status == J_OTA_STATUS_SUCCESS )
        printf("Success\n");
    else if ( status == J_OTA_STATUS_FAILED )
        printf("Failed\n");
    else
        printf("Unknown status: %d\n", status);

    return 0;
}

